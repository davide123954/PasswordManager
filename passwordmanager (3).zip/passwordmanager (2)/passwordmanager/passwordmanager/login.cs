﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace passwordmanager
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Admin" && textBox2.Text == "Aa12!123")
            {
                MessageBox.Show("Welcome " + textBox1.Text + "how are you today?");
                mainform newform = new mainform();
                //this.Hide();
                newform.Closed += (s, args) => this.Close();
                newform.Show();
            }
            //Bdika mispar 19-000
            if (textBox1.Text == "" && textBox2.Text!= "")
                MessageBox.Show("Field Username is mandatory,cant be empty", "Check Inputs", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //Bdika mispar 13-000
            if (textBox2.Text == "" && textBox1.Text!="")
                MessageBox.Show("Password can t be empty", "Check Inputs", MessageBoxButtons.OK, MessageBoxIcon.Error);
            if (textBox2.Text.ToString().Length != 8 && textBox1.Text!="")
                MessageBox.Show("Password must be exactly 8 characters", "Check Inputs", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //Bdika mispar 20-000
            if (textBox1.Text == "" && textBox2.Text == "")
                MessageBox.Show("Booth fiels cant be empty");
            // New Bdika mispar 23-000 
            if (!(textBox1.Text == "Admin") || (!(textBox2.Text == "Aa12!123")) && textBox2.Text.ToString().Length == 8)
                MessageBox.Show("One of field are not correct check yourself please ..", "Check Inputs", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //New Bdika mispar 23-000 
           // הסתרת סיסמה מהמשתמש בהוספה של סימן *
            
        }
    }
}
