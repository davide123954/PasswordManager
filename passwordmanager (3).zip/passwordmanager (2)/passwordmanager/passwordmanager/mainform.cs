﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace passwordmanager
{
    public partial class mainform : Form
    {
        public mainform()
        {
            InitializeComponent();
        }

        private void LoadList()
        {
            listBox1.Items.Clear();
            try
            {
                FileStream fs = new FileStream("list.bin", FileMode.Open);
                BinaryReader br = new BinaryReader(fs);
                while (br.PeekChar() > 0)
                {
                    listBox1.Items.Add(br.ReadString());
                    br.ReadString();
                    br.ReadString();
                }
                br.Close();
                fs.Close();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private String generatePassword()
        {
            String pass = "";
            char key;
            Random rand = new Random();
            int res;
            for (int i = 0; i < 8; i++)
            {
                res = rand.Next(4);
                switch (res)
                {
                    //Upper case
                    case 0:
                        key = (char)(rand.Next(26) + 'A');
                        pass += key;
                        break;
                    //Lower case
                    case 1:
                        key = (char)(rand.Next(26) + 'a');
                        pass += key;
                        break;
                    //Numbers
                    case 2:
                        pass += rand.Next(10);
                        break;
                    //Symbols
                    case 3:
                        if(rand.Next(2)==0)
                            key = (char)(rand.Next(15) + '!');
                        else
                            key = (char)(rand.Next(7) + ':');
                        pass += key;
                        break;
                }
            }
            return pass;
        }

        private bool testPass(String pass)
        {
            if (pass.Length != 8)
            {
                return false;
            }
              
            bool upper = true, lower = true, number = true, sign = true;
            for (int i = 0; i < 8; i++)
            {
                if (pass[i] >= 'A' && pass[i] <= 'Z')
                    upper = false;
                else if (pass[i] >= 'a' && pass[i] <= 'z')
                    lower = false;
                else if (pass[i] >= '0' && pass[i] <= '9')
                    number = false;
                else
                    sign = false;
            }
            if (upper || lower || number || sign)
                return false;
            return true;
        }
        private void generateBtn_Click(object sender, EventArgs e)
        {
            String pass = "";
            do
            {
                pass = generatePassword();
            } while (!testPass(pass));
            passBox.Text = pass;
        }
        private void addBtn_Click(object sender, EventArgs e)
        {

            if (!testPass(passBox.Text))
                //MessageBox.Show("Password not strong");
                //osafa ma ze omer password not strong...must explain what password mean strong
                MessageBox.Show("Password must be with uppercase,lowercase,symbol and numbers.");
            //Bdika 21-000 
            if (siteBox.Text == "" || userBox.Text == "" || passBox.Text=="")
                MessageBox.Show("All field are required", "Check Inputs", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            if (siteBox.Text!=null&&userBox.Text!=null&&testPass(passBox.Text))
            {
                FileStream fs = new FileStream("list.bin", FileMode.Append);
                BinaryWriter bw = new BinaryWriter(fs);
                try
                {
                    bw.Write(siteBox.Text);
                    bw.Write(userBox.Text);
                    bw.Write(passBox.Text);
                    bw.Close();
                    fs.Close();
                    LoadList();
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                    bw.Close();
                    fs.Close();
                }
            }
        }
        private void mainform_Load(object sender, EventArgs e)
        {
            LoadList();
        }

        
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem!= null)
            {
                FileStream fs = new FileStream("list.bin", FileMode.Open);
                BinaryReader br = new BinaryReader(fs);
                while (br.PeekChar() > 0)
                {
                    if (br.ReadString() == listBox1.SelectedItem.ToString())
                    {
                        userLbl.Text=br.ReadString();
                        passwordLbl.Text = br.ReadString();
                        Clipboard.SetText(passwordLbl.Text);
                        break;
                    }
                    else
                    {
                        br.ReadString();
                        br.ReadString();
                    }
                }
                br.Close();
                fs.Close();
            }
        }

        private void userBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void siteBox_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
